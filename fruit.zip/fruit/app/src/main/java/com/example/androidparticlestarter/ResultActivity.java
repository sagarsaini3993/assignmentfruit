package com.example.androidparticlestarter;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import io.particle.android.sdk.cloud.ParticleCloud;
import io.particle.android.sdk.cloud.ParticleCloudSDK;
import io.particle.android.sdk.cloud.ParticleDevice;
import io.particle.android.sdk.cloud.ParticleEvent;
import io.particle.android.sdk.cloud.ParticleEventHandler;
import io.particle.android.sdk.cloud.exceptions.ParticleCloudException;
import io.particle.android.sdk.utils.Async;

public class ResultActivity extends AppCompatActivity {
    // MARK: Debug info
    private final String TAG = "jenelle";
    int level = 0;
    int winResult = 0;
    // Data data = new Data();
    List<String> Result;
    boolean check = false;
    String data[] = {"", "", ""};
    private final String PARTICLE_USERNAME = "shrana2890@gmail.com";
    private final String PARTICLE_PASSWORD = "Shranarana48";

    // MARK: Particle device-specific info
    private final String DEVICE_ID = "44002c000f47363333343437";


    // MARK: Particle Publish / Subscribe variables
    private long subscriptionId;

    // MARK: Particle device
    private List<ParticleDevice> mDevice;
    // private ParticleDevice mDevice;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);
        //ParticleCloudSDK.init(this.getApplicationContext());
        getDeviceFromCloud();
       // changeColorsPressed();
        ResultSubscribePressed();

    }

    public void playAgain(View view) {
        Intent i = new Intent(ResultActivity.this, MainActivity.class);
        startActivity(i);
    }

    private void runThread(String d[]) {
        runOnUiThread(new Thread(new Runnable() {
            @Override
            public void run() {

                TextView t = (TextView) (findViewById(R.id.textView2));
                t.setText(mDevice.get(0).getName() + " : " + d[0]);
                TextView t1 = (TextView) (findViewById(R.id.textView3));
                t1.setText(mDevice.get(1).getName() + " : " + d[1]);
//                    TextView t2 = (TextView)(findViewById(R.id.textView4));
//                    t2.setText(mDevice.get(2).getName()+" : " + d[2]);
                //Log.d(TAG, "you loss");

            }
        }));

    }

    public void ResultSubscribePressed() {
        Async.executeAsync(ParticleCloudSDK.getCloud(), new Async.ApiWork<ParticleCloud, Object>() {

            @Override
            public Object callApi(@NonNull ParticleCloud particleCloud) throws ParticleCloudException, IOException {
//                subscriptionId = ParticleCloudSDK.getCloud().subscribeToDeviceEvents(
//                        "button", DEVICE_ID,  // the first argument, "eventNamePrefix", is optional
//                        new ParticleEventHandler() {
//                            public void onEvent(String eventName, ParticleEvent event) {
//                                Log.i(TAG, "Received event with payload: " + event.dataPayload);
//                                runThread(event.dataPayload);
//
//                            }
//
//                            public void onEventError(Exception e) {
//                                Log.e(TAG, "Event error: ", e);
//                            }
//                        });
                subscriptionId = ParticleCloudSDK.getCloud().subscribeToMyDevicesEvents("win",
                        new ParticleEventHandler() {
                            public void onEvent(String eventName, ParticleEvent event) {
                                Log.i(TAG, "Received event with payload: " + event.dataPayload);
                                data[winResult] = event.dataPayload;
                                winResult = winResult + 1;
                                if (winResult >= 1) {
                                    TextView t = (TextView) (findViewById(R.id.textView2));
                                    t.setText(mDevice.get(0).getName() + " : " + data[0]);
                                    TextView t1 = (TextView) (findViewById(R.id.textView3));
                                    t1.setText(mDevice.get(1).getName() + " : " + data[1]);
                                   // runThread(data);
                                    winResult = 0;
                                }


                            }

                            public void onEventError(Exception e) {
                                Log.e(TAG, "Event error: ", e);
                            }
                        });


                return -1;
            }

            @Override
            public void onSuccess(Object o) {
                Log.d(TAG, "Successfully got device from Cloud");
            }

            @Override
            public void onFailure(ParticleCloudException exception) {
                Log.d(TAG, exception.getBestMessage());
            }
        });


    }

    public void getDeviceFromCloud() {
        Log.d(TAG,"get devices entered");
        // This function runs in the background
        // It tries to connect to the Particle Cloud and get your device
        Async.executeAsync(ParticleCloudSDK.getCloud(), new Async.ApiWork<ParticleCloud, Object>() {

            @Override
            public Object callApi(@NonNull ParticleCloud particleCloud) throws ParticleCloudException, IOException {
                particleCloud.logIn(PARTICLE_USERNAME, PARTICLE_PASSWORD);
                mDevice = particleCloud.getDevices();
                Log.d("jenelle", String.valueOf(mDevice.size()));
                for (int i = 0; i<mDevice.size();i++){
                    ParticleDevice m = mDevice.get(i);
                    Log.d("jenelle",mDevice.get(i).getID());
                }

                Log.d(TAG,"mdevice is:" + mDevice);
                return -1;
            }

            @Override
            public void onSuccess(Object o) {
                Log.d(TAG, "Successfully got device from Cloud");
            }

            @Override
            public void onFailure(ParticleCloudException exception) {
                Log.d(TAG, exception.getBestMessage());
            }
        });
    }

//    public void changeColorsPressed() {
//        Log.d("JENELLE", "Button pressed;");
//        // Convert these to strings
//        String r = String.valueOf("done");
//        Log.d(TAG, "name is: " + r);
//        String commandToSend = r;
//        Log.d(TAG, "Command to send to particle: " + commandToSend);
//
//
//        Async.executeAsync(ParticleCloudSDK.getCloud(), new Async.ApiWork<ParticleCloud, Object>() {
//            @Override
//            public Object callApi(@NonNull ParticleCloud particleCloud) throws ParticleCloudException, IOException {
//
//                // 2. build a list and put the r,g,b into the list
//                List<String> functionParameters = new ArrayList<String>();
//                functionParameters.add(commandToSend);
//
//                // 3. send the command to the particle
//                try {
//                    for(int m = 0; m<mDevice.size();m++) {
//                        mDevice.get(m).callFunction("results", functionParameters);
//                    }
//                    //mDevice.callFunction("results", functionParameters);
//                } catch (ParticleDevice.FunctionDoesNotExistException e) {
//                    e.printStackTrace();
//                }
//
//                return -1;
//            }
//
//            @Override
//            public void onSuccess(Object o) {
//                Log.d(TAG, "Sent start command to device.");
//            }
//
//            @Override
//            public void onFailure(ParticleCloudException exception) {
//                Log.d(TAG, exception.getBestMessage());
//            }
//        });
//
//    }
//
//

}