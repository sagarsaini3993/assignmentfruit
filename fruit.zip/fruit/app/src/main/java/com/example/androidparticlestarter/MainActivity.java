package com.example.androidparticlestarter;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

import io.particle.android.sdk.cloud.ParticleCloud;
import io.particle.android.sdk.cloud.ParticleCloudSDK;
import io.particle.android.sdk.cloud.ParticleDevice;
import io.particle.android.sdk.cloud.ParticleEvent;
import io.particle.android.sdk.cloud.ParticleEventHandler;
import io.particle.android.sdk.cloud.exceptions.ParticleCloudException;
import io.particle.android.sdk.utils.Async;

public class MainActivity extends AppCompatActivity {
    private final String TAG = "jenelle";
    private final String PARTICLE_USERNAME = "shrana2890@gmail.com";
    private final String PARTICLE_PASSWORD = "Shranarana48";

    // MARK: Particle device-specific info
    private final String DEVICE_ID = "44002c000f47363333343437";
    private String deviceId = "";

    String name = "";
    Button start;
    EditText getName;
    Data data = new Data();
    Random r = new Random();
    int x = 0;
    int y = 0;
    //String d[][];
    String Animal;
    TextView t;
    SharedPreferences sharedPreferences;
    SharedPreferences.Editor editor;
    int flag = 0;

    // MARK: Particle Account Info
//    private final String PARTICLE_USERNAME = "patelpranav1313@gmail.com";
//    private final String PARTICLE_PASSWORD = "$Patel14";

    private long subscriptionId;
   // private ParticleDevice mDevice;
   private List<ParticleDevice> mDevice;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 1. Initialize your connection to the Particle API
        ParticleCloudSDK.init(this.getApplicationContext());

        // 2. Setup your device variable
        getDeviceFromCloud();
          changeColorsPressed();

        start = (Button)(findViewById(R.id.start));
        getName = (EditText)(findViewById(R.id.name));
        t = (TextView)(findViewById(R.id.text));
        t.setText("Enter your Name");
        // name = getName.getText().toString();
        sharedPreferences = getSharedPreferences("username", MODE_PRIVATE);
        editor  = sharedPreferences.edit();

        start.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               flag = flag + 1;
                if(flag ==1) {
                Toast.makeText(getApplicationContext(), "Are you Sure that at Least Three Players Atre available",
                        Toast.LENGTH_LONG).show();
                SaveName();
                    y = r.nextInt(10);
                    x = r.nextInt(2);
                   Log.d("jenelee", "y is:"+ y);
                   // changeColorsPressed();
                    setdata(x,y);
                }
                if (flag == 2) {
                    int p = mDevice.size();
                    if(p >=1){
                        Intent i = new Intent(MainActivity.this, GameStart.class);
                        i.putExtra("name", Animal);
                        i.putExtra("AniOrFruit", x);

                        startActivity(i);
                    }else{
                        Toast.makeText(getApplicationContext(), "Sorry.. Players are less than three",
                                Toast.LENGTH_LONG).show();
                        flag = 1;
                    }

                }
            }
        });
//
        this.name = sharedPreferences.getString("name", name);

        if(this.name != "") {
            t.setText("Welome " + this.name);

            getName.setVisibility(View.GONE);
        }

    }
    public void setdata(int x, int y){
        String d[][] = data.getAnimals();
        this.Animal = d[x][y];
    }


    public void SaveName(){
        TextView t = (TextView)(findViewById(R.id.text));
        // t.setText("Enter your Name");
        getName = (EditText)(findViewById(R.id.name));

        String name1 = getName.getText().toString();



        if(!name1.equals("")){
            this.name = getName.getText().toString();
            t.setText("Welome " + name);
            editor.putString("name", name);
            editor.commit();
        }


    }

    public void getDeviceFromCloud() {
        Log.d(TAG,"get devices entered");
        // This function runs in the background
        // It tries to connect to the Particle Cloud and get your device
        Async.executeAsync(ParticleCloudSDK.getCloud(), new Async.ApiWork<ParticleCloud, Object>() {

            @Override
            public Object callApi(@NonNull ParticleCloud particleCloud) throws ParticleCloudException, IOException {
                particleCloud.logIn(PARTICLE_USERNAME, PARTICLE_PASSWORD);
                mDevice = particleCloud.getDevices();
                Log.d("jenelle", String.valueOf(mDevice.size()));
               for (int i = 0; i<mDevice.size();i++){
                  ParticleDevice m = mDevice.get(i);
                  Log.d("jenelle",mDevice.get(i).getID());
               }

                Log.d(TAG,"mdevice is:" + mDevice);
                return -1;
            }

            @Override
            public void onSuccess(Object o) {
                Log.d(TAG, "Successfully got device from Cloud");
            }

            @Override
            public void onFailure(ParticleCloudException exception) {
                Log.d(TAG, exception.getBestMessage());
            }
        });
    }

    public void changeColorsPressed() {
        Log.d("JENELLE", "Button pressed;");
        // Convert these to strings
        String r = String.valueOf(x);
        Log.d(TAG, "name is: " + r);
        String commandToSend = r;
        Log.d(TAG, "Command to send to particle: " + commandToSend);


        Async.executeAsync(ParticleCloudSDK.getCloud(), new Async.ApiWork<ParticleCloud, Object>() {
            @Override
            public Object callApi(@NonNull ParticleCloud particleCloud) throws ParticleCloudException, IOException {

                // 2. build a list and put the r,g,b into the list
                List<String> functionParameters = new ArrayList<String>();
                functionParameters.add(commandToSend);

                // 3. send the command to the particle
                try {
                    for(int m = 0; m<mDevice.size();m++) {
                        mDevice.get(m).callFunction("results", functionParameters);
                    }
                    //mDevice.callFunction("results", functionParameters);
                } catch (ParticleDevice.FunctionDoesNotExistException e) {
                    e.printStackTrace();
                }

                return -1;
            }

            @Override
            public void onSuccess(Object o) {
                Log.d(TAG, "Sent start command to device.");
            }

            @Override
            public void onFailure(ParticleCloudException exception) {
                Log.d(TAG, exception.getBestMessage());
            }
        });

    }



}
