package com.example.androidparticlestarter;

public class Data {

    String Animals[][]={{"Bonjour","Salut","Salve","Konnichiwa","Hallo", "Olá", "Nǐn hǎo", "Ciao", "Ahlan", "Namaste"},
            {"galdu",	"zalutati","Perderse","dispari","gatto","cane","topo","skudra","myra","dog"}};

    public String[][] getAnimals() {
        return Animals;

    }

}
